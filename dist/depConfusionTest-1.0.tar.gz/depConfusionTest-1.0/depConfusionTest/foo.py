def  foo123():
	print("foo")